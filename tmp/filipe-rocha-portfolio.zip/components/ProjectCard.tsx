
import React, { useState, useRef } from 'react';
import { Project } from '../types';
import { getProjectInsight } from '../services/geminiService';

interface ProjectCardProps {
  project: Project;
  isDarkMode: boolean;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, isDarkMode }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [sliderPos, setSliderPos] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);

  const fetchInsight = async () => {
    if (insight) return;
    setLoading(true);
    const text = await getProjectInsight(project.title, project.description);
    setInsight(text || "");
    setLoading(false);
  };

  const handleOpen = () => {
    setShowModal(true);
    fetchInsight();
  };

  const handleMouseMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const relativeX = x - rect.left;
    const position = Math.max(0, Math.min(100, (relativeX / rect.width) * 100));
    setSliderPos(position);
  };

  return (
    <>
      <div 
        onClick={handleOpen}
        className="masonry-item cursor-pointer overflow-hidden group relative"
      >
        <img 
          src={project.imageUrl} 
          alt={project.title}
          className="w-full h-auto transition-all duration-700 group-hover:scale-105 group-hover:opacity-90 grayscale group-hover:grayscale-0"
        />
        
        {project.category === 'ANIWALL' && project.price && (
          <div className="absolute top-4 right-4 bg-black/80 text-white text-[9px] md:text-[10px] font-bold px-3 py-1 tracking-widest uppercase backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {project.price}
          </div>
        )}

        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
      </div>

      {showModal && (
        <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-md animate-in fade-in duration-300 ${isDarkMode ? 'bg-black/90' : 'bg-white/95'}`}>
          <div className={`max-w-5xl w-full max-h-[95vh] overflow-y-auto relative rounded-sm shadow-2xl ${isDarkMode ? 'bg-[#1a1a1a] border border-white/10' : 'bg-white'}`}>
            <button 
              onClick={() => setShowModal(false)}
              className={`fixed top-8 right-8 transition-all hover:scale-125 z-[110] ${isDarkMode ? 'text-white/50 hover:text-white' : 'text-black/50 hover:text-black'}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            
            <div className="flex flex-col lg:flex-row items-center gap-10 p-8 md:p-12">
              <div className="w-full lg:w-3/5">
                {project.category === 'PHOTOGRAPHY' && project.beforeImageUrl ? (
                  <div 
                    ref={sliderRef}
                    onMouseMove={handleMouseMove}
                    onTouchMove={handleMouseMove}
                    className="relative w-full aspect-[4/3] overflow-hidden select-none cursor-ew-resize rounded-sm shadow-xl"
                  >
                    <img src={project.imageUrl} className="absolute inset-0 w-full h-full object-cover" alt="Edited" />
                    <div 
                      className="absolute inset-0 w-full h-full overflow-hidden border-r border-white/50"
                      style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
                    >
                      <img src={project.beforeImageUrl} className="absolute inset-0 w-full h-full object-cover" alt="Original" />
                    </div>
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none"
                      style={{ left: `${sliderPos}%` }}
                    >
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white text-black flex items-center justify-center text-[10px] shadow-lg">
                        <i className="fa-solid fa-arrows-left-right"></i>
                      </div>
                    </div>
                    <div className="absolute bottom-4 left-4 text-[10px] tracking-[0.2em] font-bold text-white bg-black/40 px-2 py-1 uppercase rounded-sm">Original</div>
                    <div className="absolute bottom-4 right-4 text-[10px] tracking-[0.2em] font-bold text-white bg-black/40 px-2 py-1 uppercase rounded-sm">Edição</div>
                  </div>
                ) : (
                  <img src={project.imageUrl} alt={project.title} className="w-full h-auto shadow-xl" />
                )}
              </div>
              
              <div className="w-full lg:w-2/5 flex flex-col justify-center">
                <div className="flex items-center justify-between mb-4">
                  <span className={`text-[10px] tracking-[0.3em] uppercase font-bold ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>{project.category}</span>
                  {project.price && (
                    <span className={`text-sm md:text-base font-bold tracking-widest uppercase ${isDarkMode ? 'text-white' : 'text-black'}`}>{project.price}</span>
                  )}
                </div>
                
                <h2 className={`text-3xl md:text-4xl font-light tracking-tight mb-6 ${isDarkMode ? 'text-white' : 'text-black'}`}>{project.title}</h2>
                <p className={`mb-8 leading-relaxed font-light text-base md:text-lg ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{project.description}</p>
                
                {project.category === 'ANIWALL' && project.buyUrl && (
                  <a 
                    href={project.buyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`mb-10 w-full py-4 text-center text-[11px] font-bold tracking-[0.3em] uppercase transition-all duration-300 flex items-center justify-center gap-3 ${isDarkMode ? 'bg-white text-black hover:bg-gray-200' : 'bg-black text-white hover:bg-gray-800'}`}
                  >
                    <i className="fa-brands fa-whatsapp text-lg"></i>
                    Pedir orçamento
                  </a>
                )}

                <div className={`pt-8 border-t italic ${isDarkMode ? 'border-white/5' : 'border-gray-100'}`}>
                  <h4 className={`text-[10px] font-bold uppercase tracking-widest mb-3 ${isDarkMode ? 'text-gray-600' : 'text-gray-300'}`}>IA Insight</h4>
                  {loading ? (
                    <div className="animate-pulse space-y-2">
                      <div className={`h-2 rounded w-full ${isDarkMode ? 'bg-white/5' : 'bg-gray-100'}`}></div>
                      <div className={`h-2 rounded w-2/3 ${isDarkMode ? 'bg-white/5' : 'bg-gray-100'}`}></div>
                    </div>
                  ) : (
                    <p className={`text-sm font-light leading-relaxed ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>{insight}</p>
                  )}
                </div>

                {project.category === 'PHOTOGRAPHY' && (
                  <p className="mt-8 text-[9px] tracking-[0.1em] uppercase text-gray-500 flex items-center gap-2">
                    <i className="fa-solid fa-hand-pointer"></i>
                    Passe o rato na imagem para comparar a edição
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ProjectCard;
