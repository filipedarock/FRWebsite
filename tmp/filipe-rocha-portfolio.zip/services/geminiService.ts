
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getProjectInsight(projectTitle: string, description: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explique a filosofia de design por trás de um projeto chamado "${projectTitle}". 
                 Descrição curta: ${description}. 
                 Responda em português de forma poética e profissional, com no máximo 3 frases.`,
    });
    return response.text;
  } catch (error) {
    console.error("Erro ao obter insight do Gemini:", error);
    return "Um design que fala por si só, onde cada detalhe é uma intenção transformada em forma.";
  }
}
