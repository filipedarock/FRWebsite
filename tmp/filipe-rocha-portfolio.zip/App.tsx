
import React, { useState, useMemo, useEffect } from 'react';
import { PROJECTS, CONTACT_INFO } from './constants';
import ProjectCard from './components/ProjectCard';
import { Category } from './types';

const ITEMS_PER_PAGE = 6;

const App: React.FC = () => {
  // Sort categories alphabetically: ANIWALL, BANNERS, OTHERS, PHOTOGRAPHY, SIGNATURES, SOCIAL MEDIA
  const navItems = useMemo(() => {
    const items: Category[] = ['ANIWALL', 'BANNERS', 'OTHERS', 'PHOTOGRAPHY', 'SIGNATURES', 'SOCIAL MEDIA'];
    return items.sort((a, b) => a.localeCompare(b));
  }, []);

  const [activeFilter, setActiveFilter] = useState<Category>(navItems[0]);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);

  // Reset pagination when filter changes
  useEffect(() => {
    setCurrentPage(0);
  }, [activeFilter]);

  const filteredProjects = useMemo(() => {
    return PROJECTS.filter(p => p.category === activeFilter);
  }, [activeFilter]);

  const paginatedProjects = useMemo(() => {
    const start = currentPage * ITEMS_PER_PAGE;
    return filteredProjects.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredProjects, currentPage]);

  const totalPages = Math.ceil(filteredProjects.length / ITEMS_PER_PAGE);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('dark-mode');
  };

  return (
    <div className={`relative min-h-screen md:min-h-[90vh] flex flex-col md:flex-row overflow-hidden transition-colors duration-500 ${isDarkMode ? 'bg-[#121212] text-white' : 'bg-white text-black'}`}>
      
      {/* Sidebar / Top bar - Responsive layout */}
      <aside className={`w-full md:w-24 lg:w-28 border-b md:border-b-0 md:border-r flex flex-row md:flex-col justify-between items-center py-4 md:py-12 px-6 md:px-4 z-50 shrink-0 transition-colors duration-500 ${isDarkMode ? 'border-white/5 bg-[#0a0a0a]' : 'border-gray-100 bg-white'}`}>
        {/* Theme Toggle */}
        <button 
          onClick={toggleDarkMode}
          className={`text-xl transition-all duration-300 transform hover:scale-125 ${isDarkMode ? 'text-yellow-400 hover:text-yellow-200' : 'text-gray-400 hover:text-black'}`}
          title={isDarkMode ? "Modo Claro" : "Modo Escuro"}
        >
          <i className={`fa-solid ${isDarkMode ? 'fa-sun' : 'fa-moon'}`}></i>
        </button>

        {/* Logo and Branding */}
        <div className="md:mt-auto flex flex-row md:flex-col items-center gap-4 md:gap-6">
           <div className="flex flex-row md:flex-col items-center gap-3 md:gap-0">
              <div className="w-8 h-8 rounded-full border-2 border-red-500 md:mb-6 flex items-center justify-center p-1 overflow-hidden shrink-0">
                <div className="w-full h-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 rounded-full"></div>
              </div>
              <div className="vertical-text-md text-[10px] md:text-[11px] font-bold tracking-[0.2em] md:tracking-[0.4em] whitespace-nowrap uppercase">
                Portfolio <span className={`font-light ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>Filipe Rocha</span>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:h-[90vh] overflow-y-auto overflow-x-hidden scroll-smooth custom-scrollbar">
        
        {/* Top Navigation - Alphabetical Filters */}
        <header className={`py-8 md:py-14 border-b bg-inherit/95 backdrop-blur-md sticky top-0 z-40 shrink-0 transition-colors duration-500 ${isDarkMode ? 'border-white/5' : 'border-gray-50'}`}>
          <nav className="flex justify-center items-center px-6">
            <ul className={`flex flex-wrap justify-center gap-x-4 md:gap-x-6 gap-y-3 text-[9px] md:text-[11px] font-bold tracking-[0.15em] md:tracking-[0.25em] uppercase ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
              {navItems.map((item, idx) => (
                <React.Fragment key={item}>
                  <li>
                    <button 
                      onClick={() => setActiveFilter(item)}
                      className={`hover:text-current transition-all duration-300 relative py-1 ${activeFilter === item ? (isDarkMode ? 'text-white' : 'text-black') : ''}`}
                    >
                      {item}
                      {activeFilter === item && (
                        <span className={`absolute -bottom-1 left-0 w-full h-[1px] animate-in fade-in zoom-in duration-300 ${isDarkMode ? 'bg-white' : 'bg-black'}`}></span>
                      )}
                    </button>
                  </li>
                  {idx < navItems.length - 1 && <li className={`font-thin self-center ${isDarkMode ? 'text-white/10' : 'text-gray-100'}`}>|</li>}
                </React.Fragment>
              ))}
            </ul>
          </nav>
        </header>

        {/* Gallery Content with Pagination */}
        <main className="flex-1 p-6 md:p-12 lg:p-16 flex flex-col">
          <div className="masonry-columns flex-grow min-h-[400px]">
            {paginatedProjects.map((project) => (
              <ProjectCard key={project.id} project={project} isDarkMode={isDarkMode} />
            ))}
          </div>
          
          {filteredProjects.length === 0 ? (
            <div className="py-32 text-center">
              <p className={`text-[10px] tracking-[0.4em] uppercase font-light ${isDarkMode ? 'text-gray-700' : 'text-gray-300'}`}>
                A carregar a criatividade...
              </p>
            </div>
          ) : totalPages > 1 && (
            <div className="flex justify-center items-center gap-10 mt-12 py-4">
              <button 
                disabled={currentPage === 0}
                onClick={() => setCurrentPage(p => p - 1)}
                className={`text-sm transition-all duration-300 ${currentPage === 0 ? 'opacity-20 cursor-not-allowed' : 'hover:scale-125'}`}
              >
                <i className="fa-solid fa-chevron-left"></i>
              </button>
              
              <span className={`text-[10px] tracking-[0.5em] font-medium uppercase ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                {currentPage + 1} / {totalPages}
              </span>

              <button 
                disabled={currentPage === totalPages - 1}
                onClick={() => setCurrentPage(p => p + 1)}
                className={`text-sm transition-all duration-300 ${currentPage === totalPages - 1 ? 'opacity-20 cursor-not-allowed' : 'hover:scale-125'}`}
              >
                <i className="fa-solid fa-chevron-right"></i>
              </button>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className={`p-8 md:p-12 border-t mt-auto transition-colors duration-500 ${isDarkMode ? 'border-white/5 bg-[#0c0c0c]' : 'border-gray-50 bg-gray-50/30'}`}>
          <div className="max-w-4xl mx-auto flex flex-col items-center gap-8 md:gap-10">
             <div className={`flex gap-10 md:gap-12 text-2xl ${isDarkMode ? 'text-gray-600' : 'text-gray-300'}`}>
                <a href={`mailto:${CONTACT_INFO.email}`} title="Email" className={`transition-all transform hover:scale-125 duration-300 ${isDarkMode ? 'hover:text-white' : 'hover:text-black'}`}>
                  <i className="fa-solid fa-envelope"></i>
                </a>
                <a href={CONTACT_INFO.linkedin} target="_blank" rel="noopener noreferrer" title="LinkedIn" className={`transition-all transform hover:scale-125 duration-300 ${isDarkMode ? 'hover:text-white' : 'hover:text-black'}`}>
                  <i className="fa-brands fa-linkedin-in"></i>
                </a>
                <a href="#" title="Instagram" className={`transition-all transform hover:scale-125 duration-300 ${isDarkMode ? 'hover:text-white' : 'hover:text-black'}`}>
                  <i className="fa-brands fa-instagram"></i>
                </a>
             </div>
             
             <div className="flex flex-col items-center gap-4">
               <p className={`text-[8px] md:text-[10px] tracking-[0.15em] md:tracking-[0.2em] text-center uppercase font-medium ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`}>
                 © {new Date().getFullYear()} Filipe Rocha Studio. All rights reserved.
               </p>
               
               <button 
                onClick={() => {
                   const container = document.querySelector('.flex-1.flex-col.overflow-y-auto');
                   container?.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`group w-10 h-10 rounded-full border flex items-center justify-center transition-all duration-500 shadow-sm ${isDarkMode ? 'bg-[#1a1a1a] border-white/10 hover:bg-white hover:text-black' : 'bg-white border-gray-100 hover:bg-black hover:text-white'}`}
               >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                  </svg>
               </button>
             </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;
