
export type Category = 'ANIWALL' | 'PHOTOGRAPHY' | 'SIGNATURES' | 'SOCIAL MEDIA' | 'BANNERS' | 'OTHERS';

export interface Project {
  id: string;
  title: string;
  category: Category;
  imageUrl: string;
  beforeImageUrl?: string; // Specific for Photography comparison
  description: string;
  price?: string; // New: For store items like Aniwall
  buyUrl?: string; // New: Direct link for purchase (e.g., WhatsApp)
}

export interface ContactInfo {
  email: string;
  linkedin: string;
  location: string;
}
